//
//  LittleLemon_FoodOrderingApp.swift
//  LittleLemon_FoodOrdering
//
//  Created by Sean Milfort on 3/22/23.
//

import SwiftUI

@main
struct LittleLemon_FoodOrderingApp: App {
    var body: some Scene {
        WindowGroup {
            Onboarding()
        }
    }
}
