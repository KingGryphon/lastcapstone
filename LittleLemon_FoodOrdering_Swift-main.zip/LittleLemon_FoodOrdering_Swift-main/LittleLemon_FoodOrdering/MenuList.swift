//
//  MenuList.swift
//  LittleLemon_FoodOrdering
//
//  Created by Sean Milfort on 3/23/23.
//

import SwiftUI

struct MenuList: Decodable {
    let menu : Array<MenuItem>
}
