# Little Lemon Food Ordering Application

## Project Description
This project was the final project created during Meta's iOS Developer Specialization Course. This website was the culmuniation of the iOS Developer Development Track.

This application is set to be used as a demo for creating a Food Ordering Application for the Little Lemon Restaurant. This utilizes a Login Page, pulling raw data from a Data Source and populating a Menu List, while also implenting sorting, filtering and search capabilities.

## Screenshot
![iPhoneFoodOrdering_Screenshots](https://user-images.githubusercontent.com/20054991/234370527-73617430-eac3-4359-a429-165f39a271a6.png)
